
Modify the exercise 3 code about functions using the parent selector `&` for nested classes. Style the `h2` that will have the same rules of `h1`, and an additional 1rem padding and a red border. In order to style the `h1` and `h2` use the extend method. 

**Suggestion:**

%text {
...
}

.h1-class {
@extend %text;
}
